package com.example.moviesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
